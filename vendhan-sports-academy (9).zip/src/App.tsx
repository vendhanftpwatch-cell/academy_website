/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sword, 
  Trophy, 
  Users, 
  Calendar, 
  MapPin, 
  ArrowRight, 
  CheckCircle2, 
  Instagram, 
  Facebook, 
  Twitter, 
  Mail,
  Menu, 
  X,
  Dribbble,
  Activity,
  Wind,
  Zap,
  Clock,
  Star,
  Award,
  ChevronRight,
  Sun,
  Tent,
  Flame,
  Music,
  Target
} from 'lucide-react';
import contentData from '../content.json';

// --- Constants from Content ---
const PROGRAMS = contentData.programs;
const EVENTS = contentData.events;
const COACHES = contentData.coaches;
const ACHIEVEMENTS = contentData.achievements;
const SUMMER_CAMP_FEATURES = contentData.summer_camp.features;

// --- Types ---
interface Program {
  id: string;
  title: string;
  tagline: string;
  description: string;
  image: string;
  benefits: string[];
  speciality: string;
  category: string;
}

interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
}

interface Achievement {
  label: string;
  value: string;
  icon: string;
}

interface Coach {
  name: string;
  role: string;
  image: string;
}

interface Content {
  hero: {
    badge: string;
    title: string;
    subtitle: string;
    slides: string[];
  };
  programs: Program[];
  events: Event[];
  achievements: Achievement[];
  coaches: Coach[];
  summer_camp: {
    features: {
      title: string;
      description: string;
      icon: string;
    }[];
  };
}

const ICON_MAP: Record<string, any> = {
  Trophy,
  Users,
  Clock,
  Award,
  Tent,
  Music,
  Zap,
  Activity,
  Wind,
  Target,
  Star,
  Flame,
  Sun
};

const getIcon = (name: string) => {
  const Icon = ICON_MAP[name] || Star;
  return <Icon className="w-8 h-8 text-brand-orange" />;
};

const getSmallIcon = (name: string) => {
  const Icon = ICON_MAP[name] || Star;
  return <Icon className="w-6 h-6" />;
};

// --- Context ---
const ContentContext = React.createContext<Content | null>(null);

const useContent = () => {
  const context = React.useContext(ContentContext);
  if (!context) return contentData; // Fallback to imported JSON
  return context;
};

// --- Components ---

const ContentEditor = ({ content, onSave, onCancel }: { content: Content, onSave: (newContent: Content) => void, onCancel: () => void }) => {
  const [json, setJson] = useState(JSON.stringify(content, null, 2));
  const [error, setError] = useState<string | null>(null);

  const handleSave = () => {
    try {
      const parsed = JSON.parse(json);
      onSave(parsed);
    } catch (e) {
      setError('Invalid JSON format. Please check your syntax.');
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white w-full max-w-5xl h-[85vh] rounded-3xl overflow-hidden flex flex-col shadow-2xl"
      >
        <div className="px-8 py-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
          <div>
            <h2 className="text-xl font-black text-brand-navy uppercase tracking-tighter">Content <span className="text-brand-orange">Editor</span></h2>
            <p className="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Edit your website content in real-time</p>
          </div>
          <div className="flex gap-3">
            <button 
              onClick={onCancel}
              className="px-6 py-2.5 rounded-full text-sm font-bold text-slate-600 hover:bg-slate-200 transition-all"
            >
              Cancel
            </button>
            <button 
              onClick={handleSave}
              className="px-8 py-2.5 rounded-full text-sm font-bold bg-brand-navy text-white hover:bg-slate-800 transition-all shadow-lg shadow-brand-navy/20"
            >
              Save Changes
            </button>
          </div>
        </div>
        
        <div className="flex-1 relative">
          <textarea 
            value={json}
            onChange={(e) => {
              setJson(e.target.value);
              setError(null);
            }}
            className="w-full h-full p-8 font-mono text-sm bg-slate-900 text-slate-300 outline-none resize-none focus:ring-2 focus:ring-brand-orange/50 transition-all"
            spellCheck={false}
            placeholder="Paste your JSON content here..."
          />
          {error && (
            <div className="absolute bottom-6 left-6 right-6 bg-red-500 text-white px-6 py-3 rounded-xl text-sm font-bold shadow-xl animate-bounce">
              {error}
            </div>
          )}
        </div>
        
        <div className="px-8 py-4 bg-slate-50 border-t border-slate-100 flex justify-between items-center">
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Tip: Ensure you maintain the JSON structure to avoid layout issues.</p>
          <div className="flex items-center gap-2 text-[10px] text-brand-orange font-bold uppercase tracking-widest">
            <div className="w-2 h-2 bg-brand-orange rounded-full animate-pulse"></div>
            Live Preview Mode
          </div>
        </div>
      </motion.div>
    </div>
  );
};

const Navbar = ({ onEdit }: { onEdit?: () => void }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Programs', href: '#programs' },
    { name: 'Summer Camp', href: '#summer-camp' },
    { name: 'Rental', href: '#rental' },
    { name: 'Events', href: '#events' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'About', href: '#about' },
  ];

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white/90 backdrop-blur-md shadow-sm py-3' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-brand-orange rounded-lg flex items-center justify-center text-white font-bold text-xl">V</div>
          <span className={`font-display font-bold text-xl tracking-tight ${isScrolled ? 'text-brand-navy' : 'text-white'}`}>VENDHAN</span>
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link, idx) => (
            <motion.a 
              key={link.name} 
              href={link.href} 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 + idx * 0.1 }}
              className={`text-sm font-medium transition-colors hover:text-brand-orange ${isScrolled ? 'text-slate-600' : 'text-white/90'}`}
            >
              {link.name}
            </motion.a>
          ))}
          
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            onClick={onEdit}
            className={`p-2 rounded-full transition-all ${isScrolled ? 'bg-brand-orange/10 text-brand-orange hover:bg-brand-orange/20' : 'bg-white/10 text-white hover:bg-white/20'}`}
            title="Edit Content"
          >
            <Zap className="w-5 h-5" />
          </motion.button>

          <motion.a 
            href="#join" 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="bg-brand-orange text-white px-6 py-2.5 rounded-full text-sm font-semibold hover:bg-orange-600 transition-all shadow-lg shadow-orange-500/20"
          >
            Join Academy
          </motion.a>
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden text-brand-navy" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
          {isMobileMenuOpen ? <X className={isScrolled ? 'text-brand-navy' : 'text-white'} /> : <Menu className={isScrolled ? 'text-brand-navy' : 'text-white'} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-b border-slate-100 overflow-hidden"
          >
            <div className="px-6 py-8 flex flex-col gap-6">
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href} 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-lg font-semibold text-slate-800"
                >
                  {link.name}
                </a>
              ))}
              <a 
                href="#join" 
                onClick={() => setIsMobileMenuOpen(false)}
                className="bg-brand-orange text-white px-6 py-4 rounded-xl text-center font-bold"
              >
                Join Academy
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Hero = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const { hero } = useContent();
  const { badge, title, subtitle, slides } = hero;

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [slides.length]);

  return (
    <section className="relative h-screen flex items-center overflow-hidden bg-brand-navy">
      {/* Background Slider */}
      <div className="absolute inset-0 z-0">
        <AnimatePresence mode="wait">
          <motion.img
            key={currentSlide}
            src={slides[currentSlide]}
            initial={{ opacity: 0, scale: 1.1 }}
            animate={{ opacity: 0.8, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
            alt="Sports Training"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </AnimatePresence>
        <div className="absolute inset-0 bg-gradient-to-r from-brand-navy/60 via-transparent to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-12 w-full">
        <div className="max-w-2xl">
          <motion.span 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="inline-block px-4 py-1.5 bg-brand-orange/20 text-brand-orange rounded-full text-xs font-bold tracking-widest uppercase mb-6 border border-brand-orange/30"
          >
            {badge}
          </motion.span>
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl text-white mb-8 leading-[0.9] uppercase drop-shadow-2xl"
          >
            {title.split(' ').slice(0, -2).join(' ')} <br />
            <span className="text-brand-orange">{title.split(' ').slice(-2).join(' ')}</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.7 }}
            className="text-lg md:text-xl text-slate-300 mb-10 leading-relaxed max-w-lg"
          >
            {subtitle}
          </motion.p>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.9 }}
            className="flex flex-col sm:flex-row gap-4"
          >
            <a href="#programs" className="group bg-brand-orange text-white px-8 py-4 rounded-full font-bold text-lg flex items-center justify-center gap-2 hover:bg-orange-600 transition-all">
              Explore Programs
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </a>
            <a href="#rental" className="px-8 py-4 rounded-full font-bold text-lg text-white border border-white/30 hover:bg-white/10 transition-all flex items-center justify-center">
              Facility Rental
            </a>
          </motion.div>
        </div>
      </div>

      {/* Slide Indicators */}
      <div className="absolute bottom-10 left-6 md:left-12 z-20 flex gap-3">
        {slides.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentSlide(idx)}
            className={`h-1.5 rounded-full transition-all duration-300 ${currentSlide === idx ? 'w-12 bg-brand-orange' : 'w-4 bg-white/30'}`}
          />
        ))}
      </div>

      {/* Decorative Elements */}
      <div className="absolute bottom-10 right-10 hidden lg:block">
        <div className="flex gap-4 items-center text-white/40">
          <div className="w-20 h-px bg-white/20"></div>
          <span className="text-xs uppercase tracking-widest font-bold">Scroll to discover</span>
        </div>
      </div>
    </section>
  );
};

const Programs = () => {
  const { programs } = useContent();
  return (
    <section id="programs" className="section-padding bg-white text-brand-navy">
      <div className="max-w-[1400px] mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12 flex flex-col md:flex-row justify-between items-end gap-6"
        >
          <div className="max-w-2xl">
            <span className="text-[#D63384] font-bold tracking-[0.3em] text-xs uppercase mb-3 block">Academy Journal</span>
            <h2 className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-black uppercase tracking-tighter leading-[0.8] text-brand-navy mb-4">LATEST UPDATES</h2>
            <p className="text-slate-500 text-lg leading-relaxed">Explore our diverse training programs through our latest academy news and highlights. From traditional arts to modern sports excellence.</p>
          </div>
          <div className="hidden lg:block text-right">
            <div className="text-3xl font-serif italic text-slate-200 mb-1">Vol. 2026</div>
            <div className="h-px w-24 bg-slate-100 ml-auto"></div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-6">
          {/* Card 1: Large Featured (Tall) */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="md:col-span-2 lg:col-span-4 lg:row-span-2 relative group overflow-hidden rounded-sm min-h-[450px] md:min-h-[500px] lg:min-h-full border border-slate-100 shadow-sm flex flex-col"
          >
            <div className="flex-1 relative overflow-hidden">
              <img 
                src={programs[0].image} 
                className="w-full h-full object-cover transition-all duration-700 group-hover:scale-105" 
                referrerPolicy="no-referrer" 
              />
            </div>
            <div className="absolute bottom-6 left-6 right-6 bg-white p-6 md:p-8 shadow-2xl border border-slate-50">
              <span className="text-[#D63384] text-[10px] font-black uppercase tracking-[0.2em] mb-2 block">{programs[0].category}</span>
              <h3 className="text-3xl md:text-4xl font-black text-brand-navy leading-[0.85] mb-3 uppercase tracking-tighter">{programs[0].title}</h3>
              <p className="text-slate-600 text-sm leading-relaxed mb-4 line-clamp-3">{programs[0].description}</p>
              <div className="w-full h-1.5 bg-[#D63384]/20 mb-4 relative overflow-hidden">
                <div className="absolute top-0 left-0 h-full w-1/3 bg-[#D63384]"></div>
              </div>
              <button className="text-[10px] font-bold text-brand-navy uppercase tracking-widest hover:text-[#D63384] transition-colors">Read Full Story</button>
            </div>
          </motion.div>

          {/* Card 2: Horizontal (Image Left, White Right) */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="md:col-span-2 lg:col-span-8 flex flex-col sm:flex-row bg-white border border-slate-100 overflow-hidden rounded-sm h-full lg:h-[280px] shadow-sm"
          >
            <div className="sm:w-1/2 h-56 sm:h-full overflow-hidden">
              <img src={programs[1].image} className="w-full h-full object-cover transition-all duration-500" referrerPolicy="no-referrer" />
            </div>
            <div className="sm:w-1/2 p-6 md:p-8 flex flex-col justify-center">
              <h4 className="text-[#D63384] text-2xl md:text-3xl font-black leading-[0.9] mb-3 uppercase tracking-tighter">{programs[1].title}</h4>
              <p className="text-slate-600 text-sm leading-relaxed mb-3 line-clamp-2">{programs[1].description}</p>
              <p className="text-slate-400 text-[10px] uppercase tracking-widest font-bold">Academy News / {programs[1].category}</p>
            </div>
          </motion.div>

          {/* Card 3: Horizontal (White Left, Image Right) */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="md:col-span-2 lg:col-span-8 flex flex-col-reverse sm:flex-row bg-white border border-slate-100 overflow-hidden rounded-sm h-full lg:h-[280px] shadow-sm"
          >
            <div className="sm:w-1/2 p-6 md:p-8 flex flex-col justify-center">
              <h4 className="text-[#D63384] text-2xl md:text-3xl font-black leading-[0.9] mb-3 uppercase tracking-tighter">{programs[2].title}</h4>
              <p className="text-slate-600 text-sm leading-relaxed mb-3 line-clamp-2">{programs[2].description}</p>
              <p className="text-slate-400 text-[10px] uppercase tracking-widest font-bold">Academy News / {programs[2].category}</p>
            </div>
            <div className="sm:w-1/2 h-56 sm:h-full overflow-hidden">
              <img src={programs[2].image} className="w-full h-full object-cover transition-all duration-500" referrerPolicy="no-referrer" />
            </div>
          </motion.div>

          {/* Card 4: Horizontal (White Left, Image Right) */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="md:col-span-1 lg:col-span-6 flex flex-col-reverse sm:flex-row lg:flex-col-reverse bg-white border border-slate-100 overflow-hidden rounded-sm h-full lg:h-[350px] shadow-sm"
          >
            <div className="p-6 md:p-8 flex flex-col justify-center flex-1">
              <h4 className="text-[#D63384] text-2xl md:text-3xl font-black leading-[0.9] mb-4 uppercase tracking-tighter">{programs[3].title}</h4>
              <p className="text-slate-600 text-sm leading-relaxed mb-4 line-clamp-3">{programs[3].description}</p>
              <p className="text-slate-400 text-[10px] uppercase tracking-widest">Academy News / {programs[3].category}</p>
            </div>
            <div className="h-64 sm:h-48 lg:h-48 overflow-hidden">
              <img src={programs[3].image} className="w-full h-full object-cover transition-all duration-500" referrerPolicy="no-referrer" />
            </div>
          </motion.div>

          {/* Card 5: Horizontal (Image Left, Light Right) */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="md:col-span-1 lg:col-span-6 flex flex-col sm:flex-row lg:flex-col bg-slate-50 border border-slate-100 overflow-hidden rounded-sm h-full lg:h-[350px] shadow-sm"
          >
            <div className="h-64 sm:h-48 lg:h-48 overflow-hidden">
              <img src={programs[4].image} className="w-full h-full object-cover transition-all duration-500" referrerPolicy="no-referrer" />
            </div>
            <div className="p-6 md:p-8 flex flex-col justify-center flex-1">
              <h4 className="text-brand-navy text-2xl md:text-3xl font-black leading-[0.9] mb-4 uppercase tracking-tighter">{programs[4].title}</h4>
              <p className="text-[#D63384] text-sm leading-relaxed mb-4 line-clamp-3">{programs[4].description}</p>
              <p className="text-slate-400 text-[10px] uppercase tracking-widest">Academy News / {programs[4].category}</p>
            </div>
          </motion.div>

          {/* Remaining Programs in a sophisticated grid with images */}
          {programs.slice(5).map((program, idx) => (
            <motion.div 
              key={program.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="md:col-span-1 lg:col-span-4 bg-white overflow-hidden rounded-sm border border-slate-100 group hover:shadow-2xl transition-all duration-500 flex flex-col"
            >
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={program.image} 
                  alt={program.title} 
                  className="w-full h-full object-cover transition-all duration-700 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
                  <div className="absolute top-4 left-4">
                    <span className="bg-[#D63384] text-white text-[10px] font-black px-2 py-1 uppercase tracking-widest">
                      {program.category}
                    </span>
                  </div>
              </div>
              <div className="p-8 flex-1 flex flex-col group-hover:bg-[#D63384] transition-colors duration-500">
                <h4 className="text-brand-navy group-hover:text-white text-2xl font-black leading-tight mb-4 uppercase tracking-tighter">{program.title}</h4>
                <p className="text-slate-500 group-hover:text-white/80 text-sm leading-relaxed mb-6 line-clamp-2">{program.description}</p>
                <div className="mt-auto flex items-center gap-4">
                  <div className="w-8 h-px bg-slate-200 group-hover:bg-white/30"></div>
                  <button className="text-[10px] font-bold text-slate-400 group-hover:text-white uppercase tracking-widest">Read More</button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-12 p-10 md:p-16 bg-slate-50 border border-slate-100 rounded-sm text-center text-brand-navy relative overflow-hidden"
        >
          <div className="relative z-10">
            <h4 className="text-2xl md:text-3xl font-black mb-4 uppercase tracking-tighter max-w-4xl mx-auto leading-tight">“No matter your passion — fitness, sport, or art — we help you grow, perform, and succeed.”</h4>
            <p className="text-[#D63384] uppercase tracking-[0.4em] text-[10px] font-bold">Vendhan Sports Academy / Est. 2024</p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

const SummerCamp = () => {
  const { summer_camp } = useContent();
  const { features } = summer_camp;
  return (
    <section id="summer-camp" className="section-padding bg-brand-orange text-white overflow-hidden relative">
      {/* Decorative Sun */}
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-white/10 rounded-full blur-3xl"></div>
      
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
            className="relative"
          >
            <div className="aspect-[4/5] rounded-[2.5rem] overflow-hidden shadow-2xl border-4 border-white/20">
              <img 
                src="https://images.unsplash.com/photo-1533227268428-f9ed0900fb3b?q=80&w=1000&auto=format&fit=crop" 
                alt="Summer Camp" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-8 -right-8 bg-white p-6 rounded-2xl shadow-2xl text-brand-navy hidden md:block">
              <div className="flex items-center gap-4">
                <Sun className="w-8 h-8 text-brand-orange animate-spin-slow" />
                <div>
                  <h4 className="text-xl font-bold">April - May</h4>
                  <p className="text-slate-500 text-sm font-medium">Summer 2026</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
          >
            <h2 className="text-xs uppercase tracking-[0.2em] text-white/80 font-bold mb-3">Seasonal Special</h2>
            <h3 className="text-4xl sm:text-5xl md:text-6xl mb-6 font-bold leading-tight">Summer Camp <br /><span className="text-brand-navy">Adventure</span></h3>
            <p className="text-white/90 text-lg mb-10 leading-relaxed max-w-xl">
              Give your child a summer to remember! Our annual summer camp combines elite sports training with adventure, creativity, and lifelong friendships.
            </p>

            <div className="grid sm:grid-cols-2 gap-6">
              {features.map((feature, idx) => (
                <motion.div 
                  key={idx}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="flex gap-4"
                >
                  <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center shrink-0">
                    {feature.icon}
                  </div>
                  <div>
                    <h4 className="text-lg font-bold mb-1">{feature.title}</h4>
                    <p className="text-white/70 text-sm leading-snug">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="mt-12 flex flex-wrap gap-4">
              <button className="bg-brand-navy text-white px-10 py-4 rounded-full font-bold text-lg hover:scale-105 transition-all shadow-xl shadow-black/20">
                Register Now
              </button>
              <div className="flex items-center gap-3 px-6 py-4 bg-white/10 rounded-full border border-white/20">
                <Flame className="w-5 h-5 text-brand-navy" />
                <span className="font-bold">Limited Slots Available!</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const FacilityRental = () => {
  return (
    <section id="rental" className="section-padding bg-brand-navy text-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-brand-orange/5 -skew-x-12 translate-x-1/4"></div>
      
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1, ease: [0.21, 0.47, 0.32, 0.98] }}
          >
            <h2 className="text-xs uppercase tracking-[0.2em] text-brand-orange font-bold mb-3">Infrastructure</h2>
            <h3 className="text-4xl md:text-5xl mb-6 leading-tight">Facility Rental</h3>
            <p className="text-slate-400 text-lg mb-10 leading-relaxed max-w-xl">
              We offer world-class sports infrastructure for rent, suitable for practice sessions, tournaments, and private events. Our facilities are maintained to international standards.
            </p>
            
            <div className="space-y-5">
              <div className="flex items-start gap-4 p-5 bg-white/5 rounded-2xl border border-white/10">
                <div className="w-10 h-10 bg-brand-orange/20 rounded-xl flex items-center justify-center text-brand-orange shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-lg font-bold mb-1">Court / Ground Rental</h4>
                  <p className="text-slate-400 text-sm">Available at a fixed price per hour. Perfect for teams and clubs.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4 p-5 bg-white/5 rounded-2xl border border-white/10">
                <div className="w-10 h-10 bg-brand-orange/20 rounded-xl flex items-center justify-center text-brand-orange shrink-0">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-lg font-bold mb-1">Per Person Access</h4>
                  <p className="text-slate-400 text-sm">Pricing available based on number of participants. Ideal for individuals.</p>
                </div>
              </div>
            </div>

            <button className="mt-10 bg-white text-brand-navy px-8 py-4 rounded-full font-bold hover:bg-brand-orange hover:text-white transition-all">
              Book Our Facilities
            </button>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1, ease: [0.21, 0.47, 0.32, 0.98] }}
            className="relative"
          >
            <div className="aspect-square rounded-[2.5rem] overflow-hidden shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1595435064219-c7813844d529?q=80&w=1000&auto=format&fit=crop" 
                alt="Facility" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 glass-card p-6 rounded-2xl text-brand-navy hidden md:block">
              <div className="flex items-center gap-4 mb-2">
                <div className="flex -space-x-2">
                  {[1,2,3].map(i => (
                    <div key={i} className="w-7 h-7 rounded-full border-2 border-white bg-slate-200 overflow-hidden">
                      <img src={`https://i.pravatar.cc/100?img=${i+10}`} alt="user" />
                    </div>
                  ))}
                </div>
                <span className="text-xs font-bold">50+ Bookings this week</span>
              </div>
              <p className="text-[10px] text-slate-500">Join the community of elite athletes</p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const Events = () => {
  return (
    <section id="events" className="section-padding bg-slate-50">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, ease: [0.21, 0.47, 0.32, 0.98] }}
          className="text-center mb-16"
        >
          <h2 className="text-xs uppercase tracking-[0.2em] text-brand-orange font-bold mb-4">Stay Tuned</h2>
          <h3 className="text-4xl md:text-5xl text-brand-navy">Upcoming Events</h3>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {EVENTS.map((event, idx) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.8, delay: idx * 0.15, ease: [0.21, 0.47, 0.32, 0.98] }}
              className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm hover:shadow-xl transition-all group flex flex-col h-full"
            >
              <div className="flex items-center gap-2 text-brand-orange font-bold text-xs mb-4 uppercase tracking-widest">
                <Calendar className="w-4 h-4" />
                {event.date}
              </div>
              <h4 className="text-xl font-bold mb-4 text-brand-navy group-hover:text-brand-orange transition-colors leading-tight">{event.title}</h4>
              <p className="text-slate-600 text-sm mb-8 flex-1 leading-relaxed">
                {event.description}
              </p>
              <button className="w-full py-3 rounded-xl border border-slate-200 font-bold text-xs uppercase tracking-widest text-slate-700 hover:bg-brand-navy hover:text-white transition-all">
                Event Details
              </button>
            </motion.div>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1, ease: [0.21, 0.47, 0.32, 0.98] }}
          className="mt-16 bg-brand-navy rounded-2xl p-8 md:p-10 text-white flex flex-col md:flex-row items-center gap-8"
        >
          <div className="shrink-0 flex items-center gap-4">
            <div className="w-10 h-10 bg-brand-orange rounded-full flex items-center justify-center animate-pulse">
              <Zap className="w-5 h-5" />
            </div>
            <span className="font-bold text-lg uppercase tracking-wider">Latest Updates</span>
          </div>
          <div className="h-px w-full md:w-px md:h-10 bg-white/20"></div>
          <div className="flex-1 space-y-3">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-4 h-4 text-brand-orange" />
              <p className="text-slate-300 text-sm">New training center opening in Chennai.</p>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-4 h-4 text-brand-orange" />
              <p className="text-slate-300 text-sm">International Silambam seminar featuring grandmasters.</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

const Gallery = () => {
  const [filter, setFilter] = useState('All');
  const categories = ['All', 'Silambam', 'Football', 'Yoga', 'Athletics', 'Skating'];
  
  const images = [
    { cat: 'Silambam', url: 'https://images.unsplash.com/photo-1555597673-b21d5c935865?q=80&w=600' },
    { cat: 'Football', url: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?q=80&w=600' },
    { cat: 'Yoga', url: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?q=80&w=600' },
    { cat: 'Athletics', url: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?q=80&w=600' },
    { cat: 'Skating', url: 'https://images.unsplash.com/photo-1547447134-cd3f5c716030?q=80&w=600' },
    { cat: 'Silambam', url: 'https://images.unsplash.com/photo-1599058917233-3583e71f26d2?q=80&w=600' },
  ];

  const filteredImages = filter === 'All' ? images : images.filter(img => img.cat === filter);

  return (
    <section id="gallery" className="section-padding bg-white">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, ease: [0.21, 0.47, 0.32, 0.98] }}
          className="text-center mb-12"
        >
          <h2 className="text-xs uppercase tracking-[0.2em] text-brand-orange font-bold mb-4">Visual Journey</h2>
          <h3 className="text-3xl md:text-5xl text-brand-navy mb-8">Gallery</h3>
          
          <div className="flex flex-wrap justify-center gap-2 md:gap-4">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-6 py-2 rounded-full text-sm font-bold transition-all ${filter === cat ? 'bg-brand-orange text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
              >
                {cat}
              </button>
            ))}
          </div>
        </motion.div>

        <motion.div 
          layout
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6"
        >
          <AnimatePresence mode='popLayout'>
            {filteredImages.map((img, idx) => (
              <motion.div
                key={img.url}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4 }}
                className="aspect-square rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all relative group"
              >
                <img 
                  src={img.url} 
                  alt={img.cat} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-brand-navy/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-6">
                  <span className="text-white font-bold text-sm uppercase tracking-widest">{img.cat}</span>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
};

const ExpertGuidance = () => {
  return (
    <section id="about" className="section-padding bg-slate-50">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, ease: [0.21, 0.47, 0.32, 0.98] }}
          className="grid lg:grid-cols-2 gap-12 items-center mb-20"
        >
          <div>
            <span className="text-brand-orange font-bold tracking-[0.2em] text-xs uppercase mb-3 block">Welcome to our academy</span>
            <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-brand-navy mb-6 leading-tight uppercase">Where Passion Meets Performance</h2>
            <p className="text-slate-600 text-lg leading-relaxed mb-8 max-w-xl">
              With over 2 years of experience, we have successfully trained and guided students to achieve excellence in both sports and arts. Our academy is proud to have 50+ active students and has achieved remarkable success with 100+ medals and certificates in various competitions.
            </p>
            
            <div className="grid sm:grid-cols-2 gap-8">
              <div className="space-y-3">
                <h4 className="text-brand-navy font-bold flex items-center gap-2">
                  <Target className="w-5 h-5 text-brand-orange" />
                  Our Mission
                </h4>
                <p className="text-slate-500 text-sm leading-relaxed">To build confidence, discipline, and excellence in every student by providing high-quality training in sports and arts.</p>
              </div>
              <div className="space-y-3">
                <h4 className="text-brand-navy font-bold flex items-center gap-2">
                  <Zap className="w-5 h-5 text-brand-orange" />
                  Why Choose Us
                </h4>
                <ul className="text-slate-500 text-sm space-y-1 leading-relaxed">
                  <li>• Experienced and dedicated trainers</li>
                  <li>• Focus on fitness & skill development</li>
                  <li>• Proven track record with 100+ achievements</li>
                  <li>• Friendly and motivating environment</li>
                  <li>• Suitable for all age groups</li>
                </ul>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="aspect-square rounded-[2.5rem] overflow-hidden shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?q=80&w=1000&auto=format&fit=crop" 
                alt="Academy Training" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-8 -right-8 bg-brand-orange p-8 rounded-2xl shadow-2xl text-white">
              <div className="text-4xl font-black mb-1">2+</div>
              <div className="text-[10px] uppercase tracking-widest font-bold">Years of Excellence</div>
            </div>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, ease: [0.21, 0.47, 0.32, 0.98] }}
          className="text-center mb-16"
        >
          <h2 className="text-xs uppercase tracking-[0.2em] text-brand-orange font-bold mb-4">The Mentors</h2>
          <h3 className="text-4xl md:text-5xl text-brand-navy">Expert Guidance</h3>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {COACHES.map((coach, idx) => (
            <motion.div
              key={coach.name}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.8, delay: idx * 0.15, ease: [0.21, 0.47, 0.32, 0.98] }}
              className="text-center group"
            >
              <div className="relative mb-6 inline-block">
                <div className="w-48 h-48 md:w-56 md:h-56 rounded-full overflow-hidden border-4 border-white shadow-xl mx-auto relative z-10">
                  <img 
                    src={coach.image} 
                    alt={coach.name} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="absolute top-0 right-0 w-12 h-12 bg-brand-orange rounded-full -z-0 translate-x-2 -translate-y-2 flex items-center justify-center text-white shadow-lg">
                  <Star className="w-5 h-5 fill-current" />
                </div>
              </div>
              <h4 className="text-xl font-bold text-brand-navy mb-1 group-hover:text-brand-orange transition-colors">{coach.name}</h4>
              <p className="text-brand-orange font-bold text-[10px] uppercase tracking-[0.2em] mb-4">{coach.role}</p>
              <div className="flex justify-center gap-3">
                <a href="#" className="w-8 h-8 rounded-full bg-white shadow-sm flex items-center justify-center text-slate-400 hover:text-brand-orange transition-all hover:shadow-md">
                  <Instagram className="w-4 h-4" />
                </a>
                <a href="#" className="w-8 h-8 rounded-full bg-white shadow-sm flex items-center justify-center text-slate-400 hover:text-brand-orange transition-all hover:shadow-md">
                  <Twitter className="w-4 h-4" />
                </a>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Stats Section */}
        <div className="mt-24 grid grid-cols-2 lg:grid-cols-4 gap-8">
          {ACHIEVEMENTS.map((stat, idx) => (
            <motion.div 
              key={idx} 
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className="text-center p-8 bg-white rounded-3xl shadow-sm border border-slate-100"
            >
              <div className="flex justify-center mb-4">{stat.icon}</div>
              <div className="text-4xl font-bold text-brand-navy mb-1">{stat.value}</div>
              <div className="text-slate-500 text-sm font-medium uppercase tracking-wider">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const JoinForm = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    program: 'Silambam'
  });
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('loading');
    try {
      const response = await fetch('/api/applications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      if (response.ok) {
        setStatus('success');
        setFormData({ fullName: '', email: '', phone: '', program: 'Silambam' });
      } else {
        setStatus('error');
      }
    } catch (error) {
      console.error('Submission error:', error);
      setStatus('error');
    }
  };

  return (
    <section id="join" className="section-padding bg-white">
      <div className="max-w-5xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1, ease: [0.21, 0.47, 0.32, 0.98] }}
          className="bg-brand-navy rounded-[3rem] overflow-hidden shadow-2xl flex flex-col lg:flex-row"
        >
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="lg:w-2/5 p-12 bg-brand-orange text-white flex flex-col justify-center"
          >
            <h2 className="text-xs uppercase tracking-[0.2em] text-white/80 font-bold mb-4">Start Today</h2>
            <h3 className="text-4xl md:text-5xl mb-8">Become a Champion</h3>
            <p className="text-white/80 mb-10 leading-relaxed">
              Fill out the form to start your journey with Vendhan Sports Academy. Our team will contact you within 24 hours.
            </p>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5" />
                <span>Personalized training plans</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5" />
                <span>Expert certified coaches</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5" />
                <span>State-of-the-art facilities</span>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="lg:w-3/5 p-12 bg-white"
          >
            {status === 'success' ? (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-12">
                <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h4 className="text-2xl font-bold text-brand-navy">Application Received!</h4>
                <p className="text-slate-600">Thank you for applying. We'll get back to you shortly.</p>
                <button 
                  onClick={() => setStatus('idle')}
                  className="text-brand-orange font-bold hover:underline"
                >
                  Submit another application
                </button>
              </div>
            ) : (
              <form className="space-y-5" onSubmit={handleSubmit}>
                <div className="grid md:grid-cols-2 gap-5">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Full Name</label>
                    <input 
                      type="text" 
                      required
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      className="w-full px-5 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-brand-orange focus:ring-1 focus:ring-brand-orange outline-none transition-all text-sm" 
                      placeholder="John Doe" 
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Email Address</label>
                    <input 
                      type="email" 
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-5 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-brand-orange focus:ring-1 focus:ring-brand-orange outline-none transition-all text-sm" 
                      placeholder="john@example.com" 
                    />
                  </div>
                </div>
                
                <div className="grid md:grid-cols-2 gap-5">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Phone Number</label>
                    <input 
                      type="tel" 
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-5 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-brand-orange focus:ring-1 focus:ring-brand-orange outline-none transition-all text-sm" 
                      placeholder="+91 98765 43210" 
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Select Program</label>
                    <select 
                      value={formData.program}
                      onChange={(e) => setFormData({ ...formData, program: e.target.value })}
                      className="w-full px-5 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-brand-orange focus:ring-1 focus:ring-brand-orange outline-none transition-all bg-white text-sm"
                    >
                      {PROGRAMS.map(p => (
                        <option key={p.id} value={p.title}>{p.title}</option>
                      ))}
                    </select>
                  </div>
                </div>
                
                <button 
                  disabled={status === 'loading'}
                  className="w-full bg-brand-navy text-white py-4 rounded-xl font-bold hover:bg-slate-800 transition-all shadow-lg shadow-brand-navy/20 disabled:opacity-50"
                >
                  {status === 'loading' ? 'Submitting...' : 'Submit Application'}
                </button>
                {status === 'error' && (
                  <p className="text-red-500 text-xs text-center">Something went wrong. Please try again.</p>
                )}
              </form>
            )}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-slate-950 text-white pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 lg:col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 bg-brand-orange rounded-lg flex items-center justify-center text-white font-black text-xl">V</div>
              <span className="text-xl font-black tracking-tighter text-white uppercase">Vendhan <span className="text-brand-orange">Sports</span></span>
            </div>
            <p className="text-slate-400 max-w-md mb-8 leading-relaxed text-sm">
              Empowering the next generation of athletes through traditional wisdom and modern sports science. Join us to discover your true potential.
            </p>
            <div className="flex gap-4">
              {[Instagram, Facebook, Twitter].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-slate-400 hover:bg-brand-orange hover:text-white transition-all">
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="text-white font-bold mb-6 uppercase tracking-widest text-sm">Quick Links</h4>
            <ul className="space-y-3 text-slate-400 text-sm">
              <li><a href="#programs" className="hover:text-brand-orange transition-colors">Training Programs</a></li>
              <li><a href="#summer-camp" className="hover:text-brand-orange transition-colors">Summer Camp</a></li>
              <li><a href="#rental" className="hover:text-brand-orange transition-colors">Facility Rental</a></li>
              <li><a href="#events" className="hover:text-brand-orange transition-colors">Upcoming Events</a></li>
              <li><a href="#gallery" className="hover:text-brand-orange transition-colors">Gallery</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-white font-bold mb-6 uppercase tracking-widest text-sm">Contact Us</h4>
            <ul className="space-y-4 text-slate-400 text-sm">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-brand-orange shrink-0" />
                <span>123 Academy Road, Sports Hub, Chennai, TN 600001</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-brand-orange shrink-0" />
                <span>contact@vendhansports.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 0.5 }}
          className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-6 text-slate-500 text-xs"
        >
          <p>© 2026 Vendhan Sports Academy. All Rights Reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">Cookies</a>
          </div>
        </motion.div>
      </div>
    </footer>
  );
};

export default function App() {
  const [content, setContent] = useState<Content>(contentData);
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    const fetchContent = async () => {
      try {
        const response = await fetch('/api/content');
        if (response.ok) {
          const data = await response.json();
          setContent(data);
        }
      } catch (error) {
        console.error('Failed to fetch content:', error);
      }
    };
    fetchContent();
  }, []);

  const handleSaveContent = async (newContent: Content) => {
    try {
      const response = await fetch('/api/content', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newContent),
      });

      if (response.ok) {
        setContent(newContent);
        setIsEditing(false);
      } else {
        alert('Failed to save content. Please try again.');
      }
    } catch (error) {
      console.error('Error saving content:', error);
      alert('An error occurred while saving content.');
    }
  };

  return (
    <ContentContext.Provider value={content}>
      <div className="min-h-screen">
        <Navbar onEdit={() => setIsEditing(true)} />
        <Hero />
        <Programs />
        <SummerCamp />
        <FacilityRental />
        <Events />
        <Gallery />
        <ExpertGuidance />
        <JoinForm />
        <Footer />

        {isEditing && (
          <ContentEditor 
            content={content} 
            onSave={handleSaveContent} 
            onCancel={() => setIsEditing(false)} 
          />
        )}
      </div>
    </ContentContext.Provider>
  );
}
